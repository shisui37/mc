package io.papermc.testplugin.brigtests.example;

public enum IceCreamType {
    VANILLA,
    CHOCOLATE,
    BLUE_MOON,
    STRAWBERRY,
    WHOLE_MILK
}
